import setuptools

setuptools.setup(
    name='dynamodb_dataframes',
    version='0.0.1',
    packages=setuptools.find_packages(),
    url='',
    license='',
    author='mannh',
    author_email='',
    description=''
)
