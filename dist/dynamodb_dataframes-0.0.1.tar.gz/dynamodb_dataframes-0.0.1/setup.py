import setuptools

setuptools.setup(
    name='dynamodb_dataframes',
    version='0.0.1',
    packages=setuptools.find_packages(),
    url='https://github.com/mannharleen/dynamodb_dataframes',
    license='',
    author='mannh',
    author_email='https://www.linkedin.com/in/harleenmann1/',
    description=''
)
